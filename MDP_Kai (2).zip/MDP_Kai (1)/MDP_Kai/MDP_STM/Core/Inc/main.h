/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"
//#include "i2c.h"
#include "ICM20948_ADDR.h"
#include "ICM20948_OPTIONS.h"
#include "ICM20948.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

void HAL_TIM_MspPostInit(TIM_HandleTypeDef *htim);

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define OLED_SCL_Pin GPIO_PIN_5
#define OLED_SCL_GPIO_Port GPIOE
#define OLED_SDA_Pin GPIO_PIN_6
#define OLED_SDA_GPIO_Port GPIOE
#define MotorA_IN2_Pin GPIO_PIN_2
#define MotorA_IN2_GPIO_Port GPIOA
#define MotorA_IN1_Pin GPIO_PIN_3
#define MotorA_IN1_GPIO_Port GPIOA
#define MotorB_IN1_Pin GPIO_PIN_4
#define MotorB_IN1_GPIO_Port GPIOA
#define MotorB_IN2_Pin GPIO_PIN_5
#define MotorB_IN2_GPIO_Port GPIOA
#define EncoderB_CH1_Pin GPIO_PIN_6
#define EncoderB_CH1_GPIO_Port GPIOA
#define EncoderB_CH2_Pin GPIO_PIN_7
#define EncoderB_CH2_GPIO_Port GPIOA
#define OLED_RST_Pin GPIO_PIN_7
#define OLED_RST_GPIO_Port GPIOE
#define OLED_DC_Pin GPIO_PIN_8
#define OLED_DC_GPIO_Port GPIOE
#define TRIG_Pin GPIO_PIN_13
#define TRIG_GPIO_Port GPIOE
#define ServoMotor_Pin GPIO_PIN_14
#define ServoMotor_GPIO_Port GPIOE
#define ultra_ECHO_Pin GPIO_PIN_12
#define ultra_ECHO_GPIO_Port GPIOD
#define MotorA_PWM_Pin GPIO_PIN_6
#define MotorA_PWM_GPIO_Port GPIOC
#define MotorB_PWM_Pin GPIO_PIN_7
#define MotorB_PWM_GPIO_Port GPIOC
#define EncoderA_CH1_Pin GPIO_PIN_15
#define EncoderA_CH1_GPIO_Port GPIOA
#define EncoderA_CH2_Pin GPIO_PIN_3
#define EncoderA_CH2_GPIO_Port GPIOB
#define I2C1_SDA_Pin GPIO_PIN_9
#define I2C1_SDA_GPIO_Port GPIOB
#define I2C1_SCL_Pin GPIO_PIN_8
#define I2C1_SCL_GPIO_Port GPIOB

/*#define __Gyro_Read_Z(_I2C, readGyroData, gyroZ) ({ \
	HAL_I2C_Mem_Read(_I2C,ICM20948__I2C_SLAVE_ADDRESS_1 << 1, ICM20948__USER_BANK_0__GYRO_ZOUT_H__REGISTER, I2C_MEMADD_SIZE_8BIT, readGyroData, 2, 0xFFFF); \
	gyroZ = readGyroData[0] << 8 | readGyroData[1]; \
})*/

#define __Gyro_Read_Z(_I2C, readGyroData, gyroZ) ({ \
    HAL_I2C_Mem_Read(_I2C, ICM20948__I2C_SLAVE_ADDRESS_1 << 1, \
        ICM20948__USER_BANK_0__GYRO_ZOUT_H__REGISTER, I2C_MEMADD_SIZE_8BIT, \
        readGyroData, 2, 0xFFFF); \
    gyroZ = readGyroData[0] << 8 | readGyroData[1]; \
})
#define __GET_ENCODER_TICK_DELTA(_TIMER, LAST_TICK, _DIST) ({ \
    uint32_t CUR_TICK = __HAL_TIM_GET_COUNTER(_TIMER); \
    if (__HAL_TIM_IS_TIM_COUNTING_DOWN(_TIMER)) { \
        _DIST = (CUR_TICK <= LAST_TICK) ? LAST_TICK - CUR_TICK : (65535 - CUR_TICK) + LAST_TICK; \
    } else { \
        _DIST = (CUR_TICK >= LAST_TICK) ? CUR_TICK - LAST_TICK : (65535 - LAST_TICK) + CUR_TICK; \
    } \
    LAST_TICK = CUR_TICK; \
})
#define __SET_CMD_CONFIG(cfg, _MTIMER, _STIMER, targetAngle) ({ \
    __SET_SERVO_TURN(_STIMER, (cfg).servoTurnVal); \
    targetAngle = (cfg).targetAngle; \
    __SET_MOTOR_DIRECTION((cfg).direction); \
    __SET_MOTOR_DUTY(_MTIMER, (cfg).leftDuty, (cfg).rightDuty); \
})
#define __PID_SPEED_T(cfg, error, correction, dir, newDutyL, newDutyR) ({ \
    correction = (cfg).Kp * error + (cfg).Ki * (cfg).ekSum + (cfg).Kd * ((cfg).ek1 - error); \
    (cfg).ek1 = error; \
    (cfg).ekSum += error; \
    correction = correction > DUTY_SPT_RANGE ? DUTY_SPT_RANGE : (correction < -DUTY_SPT_RANGE ? -DUTY_SPT_RANGE : correction); \
    newDutyL = INIT_DUTY_SPT_L + correction * dir; \
    newDutyR = INIT_DUTY_SPT_R - correction * dir; \
})


// Add these lines at the top of main.h // this is what i changed for main.h for accel
#define ACCEL_ADDR 0x68 << 1 // Or change to 0x69 depending on AD0 pin

// Define correct registers for ICM-20948 accelerometer
#define ACCEL_PWR_MGMT_1 0x06B
#define ACCEL_ACCEL_XOUT_H 0x2D
#define ACCEL_ACCEL_YOUT_H 0x2F
#define ACCEL_ACCEL_ZOUT_H 0x31
#define ACCEL_CONFIG 0x1C // Define this based on your sensor
#define ACCEL_DATA_FORMAT 0x1D // Define this based on your sensor



/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
